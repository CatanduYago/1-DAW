<?php

    echo "Formulario recibido. Hemos recibido los siguientes datos:<br>";

?>